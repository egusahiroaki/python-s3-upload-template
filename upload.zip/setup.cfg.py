[install]
prefix= 