#!/usr/bin/env python

import boto3

BUCKET = "watawata"
s3 = boto3.client('s3')

def lambda_handler(event, context):
    key = 'test/bbbb'
    target_html = "test dayo"
    s3.put_object(Bucket=BUCKET, Key=key, Body=target_html)